$(".back-collapse").click(function(){
  $("body").toggleClass("sidebar-collapsed ");
});